import { Hook } from '@oclif/config';
export declare const migrate: Hook<'init'>;
